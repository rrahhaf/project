<?php

// create connection
$conn = new mysqli("localhost", "root", "", "hospital_db");
$conn->set_charset("utf8");

// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
